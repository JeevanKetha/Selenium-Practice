import pytest
from selenium import webdriver

from Configure.config import TestData
@pytest.fixture(params=["Edge"],scope='class')
def init_driver(request):
    if request.param == "Edge":
        web_driver= webdriver.Edge(executable_path=TestData.Edge_executable_path)
    request.cls.driver = web_driver
    yield
    web_driver.close()