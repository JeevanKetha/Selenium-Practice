from selenium import webdriver
from selenium.webdriver.common.by import By
from Pages.BasePage import BasePage
from Configure.config import TestData
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait

class LoginPage(BasePage):


    EMAIL = (By.ID, "username")
    PASSWORD = (By.ID, "password")
    LOGIN_BUTTON = (By.ID, "loginBtn")
    SIGNUP_LINK = (By.LINK_TEXT, "Sign up")

    def __init__(self,driver):
        super()._init_(driver)
        self.driver.get(TestData.Base_URL)

    def get_login_page_title(self):
        return self.driver.title

    def is_signup_link_exist(self):
        return
        #self.is_visible(self.SIGNUP_LINK)

    def do_login(self,username,password):
        self.do_send_keys(self.EMAIL, username)
        self.do_send_keys(self.PASSWORD, password)
        self.do_click(self.LOGIN_BUTTON)


