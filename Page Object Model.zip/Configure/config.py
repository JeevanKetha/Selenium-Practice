
class TestData:
    Edge_executable_path="C:/Users/jeeva/OneDrive/Documents/webdrivers/msedgedriver.exe"

    Base_URL = "https://app.hubspot.com/login"
    USER_NAME = "naveen30@gmail.com"
    PASSWORD = "Selenium@12345"

    LOGIN_PAGE_TITLE = "HubSpot Login"